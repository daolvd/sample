function myFunction() {
    document.getElementById("demo").textContent = "I have changed!";
  }